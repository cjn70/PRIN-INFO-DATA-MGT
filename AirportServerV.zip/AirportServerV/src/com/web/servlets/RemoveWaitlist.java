package com.web.servlets;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.web.dao.SearchDAO;

/**
 * Servlet implementation class RemoveWaitlist
 */
@WebServlet("/RemoveWaitlist")
public class RemoveWaitlist extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RemoveWaitlist() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String customer_id = request.getParameter("customer-id");
		String user_type = request.getParameter("user-type");
		String flight_num = request.getParameter("flight-num");
		try {
			SearchDAO.removeWaitList(flight_num,customer_id);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		if(user_type.equals("rep")) {
			String url="/AirportServerV/rep-screen.jsp";
			response.sendRedirect(url);
		}else {
			String url="/AirportServerV/customer-screen.jsp";
			response.sendRedirect(url);
		}
		//doGet(request, response);
	}

}
