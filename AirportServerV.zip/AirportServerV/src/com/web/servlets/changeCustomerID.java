package com.web.servlets;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.web.dao.EditDAO;

/**
 * Servlet implementation class changeCustomerID
 */
@WebServlet("/changeCustomerID")
public class changeCustomerID extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public changeCustomerID() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String customer_id = request.getParameter("customer");
		String new_customer_id = request.getParameter("new-customer-id");
		try {
			EditDAO.changeCustomerID(customer_id,new_customer_id);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		String url="/AirportServerV/admin-screen.jsp";
		response.sendRedirect(url);
		//doGet(request, response);
		doGet(request, response);
	}

}
