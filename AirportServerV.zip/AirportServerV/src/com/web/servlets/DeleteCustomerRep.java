package com.web.servlets;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.web.dao.EditDAO;

/**
 * Servlet implementation class DeleteCustomerRep
 */
@WebServlet("/DeleteCustomerRep")
public class DeleteCustomerRep extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeleteCustomerRep() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String customer_id = request.getParameter("employee_id");
		boolean success = false;
		try {
			success = EditDAO.deleteCustomerRep(customer_id);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		if(success) {
			String url="/AirportServerV/admin-screen.html";
			response.sendRedirect(url);
		} else {
			String url="/AirportServerV/register.html";
			response.sendRedirect(url);
		}
		doGet(request, response);
	}

}
