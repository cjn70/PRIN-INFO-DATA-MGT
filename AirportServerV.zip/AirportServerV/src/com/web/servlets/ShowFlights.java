package com.web.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ShowFlights
 */
@WebServlet("/ShowFlights")
public class ShowFlights extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShowFlights() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String departing = request.getParameter("departing");
		String arriving = request.getParameter("arriving");
		String trip_type = request.getParameter("trip-type");
		if(trip_type.equals("RoundTrip")) {
			if(departing ==null || arriving==null ) {
				String url="/AirportServerV/search-flight.jsp";
				response.sendRedirect(url);
				return;
			}
			String url="roundtrip-flights.jsp";
			StringBuilder reqBuild = new StringBuilder();
			reqBuild.append(url);
			reqBuild.append("?departing=");
			reqBuild.append(departing);
			reqBuild.append("&");
			reqBuild.append("arriving=");
			reqBuild.append(arriving);
			reqBuild.append("&");
			reqBuild.append("trip-type=");
			reqBuild.append(trip_type);
			RequestDispatcher disp = request.getRequestDispatcher(reqBuild.toString());
		    disp.forward(request, response);
		}else {
			String url="flights.jsp";
			StringBuilder reqBuild = new StringBuilder();
			reqBuild.append(url);
			reqBuild.append("?departing=");
			reqBuild.append(departing);
			reqBuild.append("&");
			reqBuild.append("arriving=");
			reqBuild.append(arriving);
			reqBuild.append("&");
			reqBuild.append("trip-type=");
			reqBuild.append(trip_type);
			RequestDispatcher disp = request.getRequestDispatcher(reqBuild.toString());
		    disp.forward(request, response);  
		}
		doGet(request, response);
	}

}
