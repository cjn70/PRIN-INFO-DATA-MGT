package com.web.servlets;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.web.dao.GetTicketDAO;
import com.web.dao.SearchDAO;

/**
 * Servlet implementation class EnterWaitlist
 */
@WebServlet("/EnterWaitlist")
public class EnterWaitlist extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EnterWaitlist() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String flight_num = request.getParameter("flight-num");
		String customer_id = "";
		String customer_name = "null";
		try {
			customer_name=String.valueOf(request.getSession().getAttribute("customer-name"));
		} catch(Exception e) {}
		if(customer_name.equals("null") || customer_name.equals("")) {
			System.out.println("this is the username: " + (String)request.getSession().getAttribute("username"));
			customer_id = (String)request.getSession().getAttribute("username");
		} else {
			customer_id = customer_name;
		}
		System.out.println(customer_name);
		boolean success = false;
		try {
			 success = SearchDAO.enterWaitList(flight_num,customer_id); 
		} catch (SQLException e) {
			e.printStackTrace();
		}
		if(success && customer_id.equals((String)request.getSession().getAttribute("username"))) {
			String url="/AirportServerV/customer-screen.jsp";
			response.sendRedirect(url);
		} else if (success && customer_id.equals(customer_name)) {
			String url="/AirportServerV/rep-screen.jsp";
			response.sendRedirect(url);
		} else {
			String url="/AirportServerV/login.html";
			response.sendRedirect(url);
		}
		doGet(request, response);
	}

}
