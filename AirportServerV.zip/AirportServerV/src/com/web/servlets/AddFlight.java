package com.web.servlets;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.web.dao.EditDAO;

/**
 * Servlet implementation class AddFlight
 */
@WebServlet("/AddFlight")
public class AddFlight extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddFlight() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String flight_num = request.getParameter("flight-num");
		String arriving = request.getParameter("arriving");
		String arriving_time = request.getParameter("arriving-time");
		String departing = request.getParameter("departing");
		String departing_time =  request.getParameter("departing-time");
		String airline = request.getParameter("airline");
		String aircraft = request.getParameter("aircraft");
		boolean success = false;
		try {
			success = EditDAO.addFlight(flight_num,departing,departing_time,arriving,arriving_time,airline,aircraft);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		if(success) {
			String url="/AirportServerV/rep-screen.jsp";
			response.sendRedirect(url);
			return;
		} else {
			String url="add-flight.jsp.jsp";
			StringBuilder reqBuild = new StringBuilder();
			reqBuild.append(url);
			reqBuild.append("?didFail=");
			reqBuild.append("true");
			RequestDispatcher disp = request.getRequestDispatcher(reqBuild.toString());
		    disp.forward(request, response);  
		}
		//doGet(request, response);
	}

}
