package com.web.dao;
import java.util.ArrayList;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.web.beans.AirlineData;
import com.web.connections.*;
public class AirlineSelectDAO {
	public static ArrayList<AirlineData> getAirlines() throws SQLException{
		ArrayList<AirlineData> data = new ArrayList<AirlineData>();
		Connection conn = DBConnection.getConnection();
		try {
			PreparedStatement p = conn.prepareStatement("SELECT airline_id, name FROM airport.airlines;");
			ResultSet r = p.executeQuery();
			while(r.next()) {
				AirlineData a = new AirlineData();
				a.setAirline_id(r.getString("airline_id"));
				a.setName(r.getString("name"));
				data.add(a);
			}
		}catch(Exception e) {
			System.err.println("error while trying to get the list of airlines");
			e.printStackTrace();
		}
		return data;
	}
	
	public static boolean editAirline(String airline_id, String name) throws SQLException {
		Connection conn = DBConnection.getConnection();
		try {
			PreparedStatement p = conn.prepareStatement("update airlines set name=? where airline_id=?");
			p.setString(1,name);
			p.setString(2,airline_id);
			p.executeUpdate();
			return true;
		} catch(Exception e) {
			System.err.println("error while trying to edit an airline");
			e.printStackTrace();
		}
		return false;
	}
	
	public static boolean deleteAirline(String airline_id) throws SQLException{
		Connection conn = DBConnection.getConnection();
		try {
			PreparedStatement p = conn.prepareStatement("delete from airlines where airline_id=?");
			p.setString(1,airline_id);
			p.executeUpdate();
			return true;
		} catch(Exception e) {
			System.err.println("error while trying to delete an airline");
			e.printStackTrace();
		}
		return false;
	}
	
	public static boolean addAirline(String airline_id, String name) throws SQLException{
		Connection conn = DBConnection.getConnection();
		try {
			PreparedStatement p = conn.prepareStatement("insert into airlines values(?,'0','0',?);");
			p.setString(1,airline_id);
			p.setString(2,name);
			p.execute();
			return true;
		} catch(Exception e) {
			System.err.println("error while trying to add an airline");
			e.printStackTrace();
		}
		return false;
	}
}
