package com.web.dao;

import com.web.beans.*;
import com.web.connections.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CustomerSelectDAO {
	public static List<CustomerData> data(String customerName) throws SQLException {
		List<CustomerData> data = new ArrayList<CustomerData>();
		try {
    		Connection conn = DBConnection.getConnection();
    		String flightsQuery="select m.ticket_unique_num, t.class, t.meal, t.seat_number, f.flight_num,  d.airport_id as departing , d.departure_time,a.airport_id as arrival, a.arrival_time, v.airline_id as airline, u.aircraft_registration as aircraft,b.booking_fees,t.fare from airport.make_book_have__list_Reservation m inner join flight_tickets t on m.ticket_unique_num=t.ticket_unique_num inner join buys b on t.ticket_unique_num=b.ticket_unique_num inner join flights f on t.senquence=f.flight_num inner join depart_from d on f.flight_num=d.flight_num inner join arrive_at a on f.flight_num=a.flight_num inner join via v on f.flight_num=v.flight_num inner join uses u on f.flight_num=u.flight_num where m.customer_id=?";
    		PreparedStatement p = conn.prepareStatement(flightsQuery);
    		p.setString(1, customerName);
    		ResultSet r = p.executeQuery();
    		while(r.next()) {
    			CustomerData d = new CustomerData();
    			d.setTicket_unique_num(r.getString("ticket_unique_num"));
    			d.setFlight_num(r.getString("flight_num"));
    			d.setSeat_number(r.getString("seat_number"));
    			d.setMeal(r.getString("meal"));
    			d.setDeparting(r.getString("departing"));
    			d.setDeparture_time(r.getString("departure_time"));
    			d.setArrival(r.getString("arrival"));
    			d.setArrival_time(r.getString("arrival_time"));
    			d.setAirline(r.getString("airline"));
    			d.setAircraft(r.getString("aircraft"));
    			d.setBooking_fees(r.getString("booking_fees"));
    			d.setFare(r.getString("fare"));
    			data.add(d);
    		}
    	} catch(Exception e) {
    		System.err.println("Exception executing customer select getData query");
    	}
		return data;
	}
}
