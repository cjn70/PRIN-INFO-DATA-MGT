package com.web.dao;
import com.web.connections.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
public class EditDAO {
	public static boolean editFlight(String flight_num, String departing, String departure_time, String arriving, String arriving_time, String airline, String aircraft) throws SQLException{
		Connection conn = DBConnection.getConnection();
		try {
			PreparedStatement p1  = conn.prepareStatement("update flights set days=?,destination_boundary='0' where flights.flight_num=?;");
			String departure_date = departure_time.substring(0,10);
			p1.setString(1,departure_date);
			p1.setString(2,flight_num);
			p1.executeUpdate();
			PreparedStatement p2 = conn.prepareStatement("update via set airline_id=? where via.flight_num=?;");
			p2.setString(1,airline);
			p2.setString(2,flight_num);
			p2.executeUpdate();
			PreparedStatement p3 = conn.prepareStatement("update arrive_at set airport_id=?, arrival_time=? where arrive_at.flight_num=?;");
			p3.setString(1,arriving);
			p3.setString(2,arriving_time);
			p3.setString(3,flight_num);
			p3.executeUpdate();
			PreparedStatement p4 = conn.prepareStatement("update depart_from set airport_id=?, departure_time=? where depart_from.flight_num=?;");
			p4.setString(1,departing);
			p4.setString(2,departure_time);
			p4.setString(3,flight_num);
			p4.executeUpdate();
			PreparedStatement p5 = conn.prepareStatement("update via set airline_id=? where via.flight_num=?;");
			p5.setString(1,airline);
			p5.setString(2,flight_num);
			p5.execute();
			PreparedStatement p6 = conn.prepareStatement("update uses set aircraft_registration=? where flight_num=? ");
			p6.setString(1,aircraft);
			p6.setString(2,flight_num);
			p6.execute();
			return true;
		}catch(Exception e) {
			System.err.println("error while trying to edit flight information");
			e.printStackTrace();
			}
		return false;
	}
	
	public static boolean deleteFlight(String flight_num) throws SQLException{
		Connection conn = DBConnection.getConnection();
		try{
			PreparedStatement p = conn.prepareStatement("delete from flights where flight_num=?");
			p.setString(1,flight_num);
			p.execute();
			return true;
		} catch(Exception e) {
			System.err.println("error while trying to delete flight");
			e.printStackTrace();
		}
		return false;
	}
	
	public static boolean addFlight(String flight_num, String departing, String departing_time, String arriving, String arriving_time, String airline,String aircraft) throws SQLException {
		Connection conn = DBConnection.getConnection();
		try {
			PreparedStatement p1 = conn.prepareStatement("insert into flights values(?,?,'0');");
			p1.setString(1,flight_num);
			String departure_date = departing_time.substring(0,10);
			p1.setString(2,departure_date);
			p1.execute();
			PreparedStatement p2 = conn.prepareStatement("insert into arrive_at values(?,?,?);");
			p2.setString(1,flight_num);
			p2.setString(2,arriving);
			p2.setString(3,arriving_time);
			p2.execute();
			PreparedStatement p3 = conn.prepareStatement("insert into depart_from values(?,?,?);");
			p3.setString(1,flight_num);
			p3.setString(2,departing);
			p3.setString(3,departing_time);
			p3.execute();
			PreparedStatement p4 = conn.prepareStatement("insert into via values(?,?);");
			p4.setString(1,airline);
			p4.setString(2,flight_num);
			p4.execute();
			PreparedStatement p6 = conn.prepareStatement("insert into uses values(?,?); ");
			p6.setString(1,aircraft);
			p6.setString(2,flight_num);
			p6.execute();
			return true;
		} catch(Exception e) {
			System.err.println("error while trying to add a flight");
			e.printStackTrace();
		}
		return  false;
	}
	
	public static boolean deleteAirport(String airport_id) throws SQLException{
		Connection conn = DBConnection.getConnection();
		try {
			PreparedStatement p = conn.prepareStatement("delete from airports where airport_id=?;");
			p.setString(1,airport_id);
			p.execute();
			return true;
		}catch(Exception e) {
			System.err.println("error while trying to delete an airport");
			e.printStackTrace();
		}
		return false;
	}
	
	public static boolean addAirport(String airport_id) throws SQLException{
		Connection conn = DBConnection.getConnection();
		try {
			PreparedStatement p = conn.prepareStatement("insert into airports values(?);");
			p.setString(1,airport_id);
			p.execute();
			return true;
		}catch(Exception e) {
			System.err.println("error while trying to add an airport");
			e.printStackTrace();
		}
		return false;
	}
	
	public static boolean addCustomer(String customer_id, String password) throws SQLException{
		Connection conn = DBConnection.getConnection();
		try {
			PreparedStatement p = conn.prepareStatement("insert into customer values(?,?)");
			p.setString(1,customer_id);
			p.setString(2,password);
			p.execute();
			return true;
		}catch(Exception e) {
			System.err.println("error while trying to add a customer");
			e.printStackTrace();
		}
		return false;
	}
	
	public static boolean deleteCustomer(String customer_id) throws SQLException{
		Connection conn = DBConnection.getConnection();
		try {
			PreparedStatement p = conn.prepareStatement("delete from customer where customer_id=?");
			p.setString(1,customer_id);
			p.execute();
			return true;
		}catch(Exception e) {
			System.err.println("error while trying to delete a customer");
			e.printStackTrace();
		}
		return false;
	}
	
	public static boolean deleteCustomerRep(String customer_id) throws SQLException{
		Connection conn = DBConnection.getConnection();
		try {
			PreparedStatement p = conn.prepareStatement("delete from customer_representatives where employee_id=?");
			p.setString(1,customer_id);
			p.execute();
			return true;
		}catch(Exception e) {
			System.err.println("error while trying to delete a customer rep");
			e.printStackTrace();
		}
		return false;
	}
	
	public static boolean addCustomerRep(String customer_id, String password) throws SQLException{
		Connection conn = DBConnection.getConnection();
		try {
			PreparedStatement p1 = conn.prepareStatement("insert into employee values(?)");
			p1.setString(1,customer_id);
			p1.execute();
			PreparedStatement p = conn.prepareStatement("insert into customer_representatives values(?,?)");
			p.setString(1,customer_id);
			p.setString(2,password);
			p.execute();
			return true;
		}catch(Exception e) {
			System.err.println("error while trying to add a customer rep");
			e.printStackTrace();
		}
		return false;
	}
	
	public static boolean changeCustomerPassword(String customer_id, String password) throws SQLException{
		Connection conn = DBConnection.getConnection();
		try {
			PreparedStatement p = conn.prepareStatement("update customer set password=? where customer_id=?");
			p.setString(1,password);
			p.setString(2,customer_id);
			p.execute();
			return true;
		}catch(Exception e) {
			System.err.println("error while trying to change a customer password");
			e.printStackTrace();
		}
		return false;
	}
	
	public static boolean changeRepPassword(String employee_id, String password) throws SQLException{
		Connection conn = DBConnection.getConnection();
		try {
			PreparedStatement p = conn.prepareStatement("update customer_representatives set password=? where employee_id=?");
			p.setString(1,password);
			p.setString(2,employee_id);
			p.execute();
			return true;
		}catch(Exception e) {
			System.err.println("error while trying to change a customer rep password");
			e.printStackTrace();
		}
		return false;
	}
	
	public static boolean changeCustomerID(String customer_id, String new_customer_id) throws SQLException{
		Connection conn = DBConnection.getConnection();
		try {
			PreparedStatement p = conn.prepareStatement("update customer set customer_id=? where customer_id=?");
			p.setString(1,new_customer_id);
			p.setString(2,customer_id);
			p.execute();
			return true;
		}catch(Exception e) {
			System.err.println("error while trying to change a customer id");
			e.printStackTrace();
		}
		return false;
	}
	
	public static boolean changeCustomerRepID(String employee_id, String new_employee_id) throws SQLException{
		Connection conn = DBConnection.getConnection();
		try {
			PreparedStatement p = conn.prepareStatement("update customer_representatives set employee_id=? where employee_id=?");
			p.setString(1,new_employee_id);
			p.setString(2,employee_id);
			p.execute();
			return true;
		}catch(Exception e) {
			System.err.println("error while trying to change a customer rep id");
			e.printStackTrace();
		}
		return false;
	}
}

