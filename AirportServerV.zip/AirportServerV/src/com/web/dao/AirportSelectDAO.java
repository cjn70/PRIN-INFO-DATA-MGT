package com.web.dao;

import java.util.ArrayList;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.web.connections.*;

public class AirportSelectDAO {
	public static ArrayList<String> getAirports() throws SQLException{
		ArrayList<String> airports = new ArrayList<String>();
		try {
    		Connection conn = DBConnection.getConnection();
    		PreparedStatement p = conn.prepareStatement("select airport_id from airports");
    		ResultSet r = p.executeQuery();
    		
    		while(r.next()){
    			airports.add(r.getString("airport_id"));
    		}		
		} catch(Exception e) {
    		System.err.println("Exception executing airport search query");
    	}
		return airports;
	}
}
