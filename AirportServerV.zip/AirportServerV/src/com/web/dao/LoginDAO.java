package com.web.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.web.connections.*;

public class LoginDAO {
	    
	    public static boolean list(String username, String password, String type) throws SQLException {
	    	boolean valid = false; 		
	    	try {
	    		Connection conn = DBConnection.getConnection();
	    		
	    		PreparedStatement p = null;
	    		if(type.equals("Customer")) {
	    			p = conn.prepareStatement("select customer_id,password from customer where customer_id=? and password=?");
	    		}
	    		else if(type.equals("Representative")){
	    			p = conn.prepareStatement("select employee_id,password from customer_representatives where employee_id=? and password=?");
	    		}
	    		else {
	    			p = conn.prepareStatement("select employee_id,password from admin where employee_id=? and password=?");
	    		}
	    		p.setString(1, username);
	    		p.setString(2, password);
	    		
	    		ResultSet r = p.executeQuery();
	    		
	    		if(r.next()){
	    			valid = true;
	    		}
	    	} catch(Exception e) {
	    		System.err.println("Exception executing login query");
	    	}
	    	return valid;
	    }
	    
}
