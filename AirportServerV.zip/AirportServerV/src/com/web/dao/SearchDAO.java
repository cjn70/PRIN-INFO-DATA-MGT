package com.web.dao;
import com.web.beans.*;
import com.web.connections.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
public class SearchDAO {
	public static ArrayList<CustomerData> searchFlights(String departing, String arriving, String trip_type) throws SQLException{
		ArrayList<CustomerData> data = new ArrayList<CustomerData>();
		try {
    		Connection conn = DBConnection.getConnection();
    		ArrayList<String> airports = AirportSelectDAO.getAirports();
    		String statementPrefix = "select t.ticket_unique_num, t.class, t.meal, t.seat_number, f.flight_num, " + 
    				"d.airport_id as departing , d.departure_time,a.airport_id as arrival, a.arrival_time, " + 
    				"v.airline_id as airline, u.aircraft_registration as aircraft,t.fare " + 
    				"from flight_tickets t " + 
    				"inner join flights f " + 
    				"on t.senquence=f.flight_num " + 
    				"inner join depart_from d " + 
    				"on f.flight_num=d.flight_num " + 
    				"inner join arrive_at a " + 
    				"on f.flight_num=a.flight_num " + 
    				"inner join via v " + 
    				"on f.flight_num=v.flight_num " + 
    				"inner join uses u " + 
    				"on f.flight_num=u.flight_num ";
    		String statementCondition = "";
    		//Add conditional code to modify the 'where' part of the SQL statement condition NOTE does not implement trip type functionality
    		if(airports.contains(departing) && airports.contains(arriving)) {
    			statementCondition = "where d.airport_id=? and a.airport_id=?";
    		}
    		else if(airports.contains(departing) && !airports.contains(arriving)) {
    			statementCondition = "where d.airport_id=?";
    		}
    		else if(!airports.contains(departing) && airports.contains(arriving)) {
    			statementCondition = "where a.airport_id=?";
    		}else {}
    		String fullStatement = statementPrefix + " " + statementCondition;
    		
    		PreparedStatement p = conn.prepareStatement(fullStatement);
    		if(airports.contains(departing) && airports.contains(arriving)) {
    			p.setString(1,departing);
    			p.setString(2,arriving);
    		}
    		else if(airports.contains(departing) && !airports.contains(arriving)) {
    			p.setString(1,departing);
    		}
    		else if(!airports.contains(departing) && airports.contains(arriving)) {
    			p.setString(1,arriving);
    		}else {}
    		ResultSet r = p.executeQuery();
    		System.out.println("hehehehe");
    		while(r.next()) {
    			CustomerData d = new CustomerData();
    			d.setTicket_unique_num(r.getString("ticket_unique_num"));
    			d.setFlight_num(r.getString("flight_num"));
    			d.setSeat_number(r.getString("seat_number"));
    			d.setMeal(r.getString("meal"));
    			d.setDeparting(r.getString("departing"));
    			d.setDeparture_time(r.getString("departure_time"));
    			d.setArrival(r.getString("arrival"));
    			d.setArrival_time(r.getString("arrival_time"));
    			d.setAirline(r.getString("airline"));
    			d.setAircraft(r.getString("aircraft"));
    			d.setFare(r.getString("fare"));
    			data.add(d);
    		}
		} catch(Exception e) {
			System.err.println("Exception executing flight search listing query");
		}
		return data;
	}
	
	public static ArrayList<FlightData> getFlights(String departing, String arriving, String trip_type){
		ArrayList<FlightData> data = new ArrayList<FlightData>();
		try {
    		Connection conn = DBConnection.getConnection();
    		ArrayList<String> airports = AirportSelectDAO.getAirports();
    		String statementPrefix = "select d.airport_id as departing, a.airport_id as arriving, a.arrival_time, d.departure_time, ar.airline_id, f.flight_num " + 
    				"from flights f " + 
    				"inner join depart_from d on f.flight_num=d.flight_num " + 
    				"inner join arrive_at a on f.flight_num=a.flight_num " + 
    				"inner join via v on f.flight_num=v.flight_num " + 
    				"inner join airlines ar on v.airline_id=ar.airline_id "; //change to get the flight list
    		String statementCondition = "";
    		//Add conditional code to modify the 'where' part of the SQL statement condition NOTE does not implement trip type functionality
    		if(airports.contains(departing) && airports.contains(arriving)) {
    			statementCondition = "where d.airport_id=? and a.airport_id=?";
    		}
    		else if(airports.contains(departing) && !airports.contains(arriving)) {
    			statementCondition = "where d.airport_id=?";
    		}
    		else if(!airports.contains(departing) && airports.contains(arriving)) {
    			statementCondition = "where a.airport_id=?";
    		}else {}
    		String fullStatement = statementPrefix + " " + statementCondition;
    		
    		PreparedStatement p = conn.prepareStatement(fullStatement);
    		if(airports.contains(departing) && airports.contains(arriving)) {
    			p.setString(1,departing);
    			p.setString(2,arriving);
    		}
    		else if(airports.contains(departing) && !airports.contains(arriving)) {
    			p.setString(1,departing);
    		}
    		else if(!airports.contains(departing) && airports.contains(arriving)) {
    			p.setString(1,arriving);
    		}else {}
    		ResultSet r = p.executeQuery();
    		System.out.println("hehehehe");
    		while(r.next()) {
    			FlightData d = new FlightData();			
    			d.setFlight_num(r.getString("flight_num"));
    			d.setDeparting(r.getString("departing"));
    			d.setDeparting_time(r.getString("departure_time"));
    			d.setArriving(r.getString("arriving"));
    			d.setArriving_time(r.getString("arrival_time"));
    			d.setAirline(r.getString("airline_id"));
    			d.setFlight_num(r.getString("flight_num"));
    			d.isFull = SearchDAO.isFull(d.getFlight_num());
    			data.add(d);
    		}
		} catch(Exception e) {
			System.err.println("Exception executing flight search listing query");
		}
		return data;
	}
	
	public static ArrayList<CustomerData> searchFlightNum(String flight_num) throws SQLException{
		ArrayList<CustomerData> data = new ArrayList<CustomerData>();
		try {
    		Connection conn = DBConnection.getConnection();
    		String statementPrefix = "select t.ticket_unique_num, t.class, t.meal, t.seat_number, f.flight_num, " + 
    				"d.airport_id as departing , d.departure_time,a.airport_id as arrival, a.arrival_time, " + 
    				"v.airline_id as airline, u.aircraft_registration as aircraft,t.fare,t.reserved " + 
    				"from flight_tickets t " + 
    				"inner join flights f " + 
    				"on t.senquence=f.flight_num " + 
    				"inner join depart_from d " + 
    				"on f.flight_num=d.flight_num " + 
    				"inner join arrive_at a " + 
    				"on f.flight_num=a.flight_num " + 
    				"inner join via v " + 
    				"on f.flight_num=v.flight_num " + 
    				"inner join uses u " + 
    				"on f.flight_num=u.flight_num ";
    		String statementCondition = "where f.flight_num=?";
    		String fullStatement = statementPrefix + " " + statementCondition;
    		PreparedStatement p = conn.prepareStatement(fullStatement);
    		p.setString(1,flight_num);
    		ResultSet r = p.executeQuery();
    		System.out.println("hehehehe");
    		while(r.next()) {
    			if(r.getString("reserved").equals("0")) {
	    			CustomerData d = new CustomerData();
	    			d.setTicket_unique_num(r.getString("ticket_unique_num"));
	    			d.setFlight_num(r.getString("flight_num"));
	    			d.setSeat_number(r.getString("seat_number"));
	    			d.setMeal(r.getString("meal"));
	    			d.setDeparting(r.getString("departing"));
	    			d.setDeparture_time(r.getString("departure_time"));
	    			d.setArrival(r.getString("arrival"));
	    			d.setArrival_time(r.getString("arrival_time"));
	    			d.setAirline(r.getString("airline"));
	    			d.setAircraft(r.getString("aircraft"));
	    			d.setFare(r.getString("fare"));
	    			data.add(d);
    			}
    		}
		} catch(Exception e) {
			System.err.println("Exception executing flight num search listing query");
		}
		return data;
	}
	public static boolean isFull(String flight_num) throws SQLException {
		Connection conn = DBConnection.getConnection();
		try {
			PreparedStatement p = conn.prepareStatement("select u.flight_num, a.num_seats, count(b.ticket_unique_num) customer_num from aircrafts a, buys b, valid v, uses u " + 
					"	where b.ticket_unique_num = v.ticket_unique_num and u.flight_num=? " + 
					"	and u.flight_num = v.flight_num and a.aircraft_registration= u.aircraft_registration " + 
					"    group by a.aircraft_registration having count(b.ticket_unique_num) >=  a.num_seats;"); //NEEDS REPLACING/FIXING
			p.setString(1,flight_num);
			ResultSet r = p.executeQuery();
			if(!r.next()) {
				return false;
			}
			if(r.getString("flight_num").equals(flight_num)){ //here
				return true;
			}
			else {
				return false;
			}
		}catch(Exception e) {
			System.err.println("error while trying to check if a flight is full");
			e.printStackTrace();
			return false;
		}
	}
	public static ArrayList<String> getCustomersWaitingFor(String flight_num){ 
		ArrayList<String> data = new ArrayList<String>();
		Connection conn = DBConnection.getConnection();
		try {
			PreparedStatement p = conn.prepareStatement("select customer_id from is_has_waiting_list where flight_num=?"); //here
			p.setString(1,flight_num);
			ResultSet r = p.executeQuery();
			while(r.next()) {
				data.add(r.getString("customer_id")); //here
			}
		}catch(Exception e) {
			System.err.println("error while trying to get the waiting list for a flight");
			e.printStackTrace();
		}
		return data;
	}
	
	public static ArrayList<String> getWaitingFlightsFor(String customer_id) throws SQLException{ 
		ArrayList<String> data = new ArrayList<String>();
		Connection conn = DBConnection.getConnection();
		try {
			PreparedStatement p = conn.prepareStatement("select flight_num from is_has_waiting_list where customer_id=?"); //here
			p.setString(1,customer_id);
			ResultSet r = p.executeQuery();
			while(r.next()) {
				data.add(r.getString("flight_num")); //here
			}
		}catch(Exception e) {
			System.err.println("error while trying to get the waiting list for a customer");
			e.printStackTrace();
		}
		return data;
	}
	
	public static boolean enterWaitList(String flight_num, String customer_id) throws SQLException{
		Connection conn = DBConnection.getConnection();
		try {
			PreparedStatement p = conn.prepareStatement("insert into is_has_waiting_list values(?,?)");
			p.setString(1,flight_num);
			p.setString(2,customer_id);
			p.execute();
			return true;
		}catch(Exception e) {
			System.err.println("error while trying to add a customer to the waiting list");
			e.printStackTrace();
		}
		return false;
	}
	
	public static boolean removeWaitList(String flight_num, String customer_id) throws SQLException{
		Connection conn = DBConnection.getConnection();
		try {
			PreparedStatement p = conn.prepareStatement("delete from is_has_waiting_list where customer_id=? and flight_num=?");
			p.setString(1,customer_id);
			p.setString(2,flight_num);
			p.execute();
			return true;
		}catch(Exception e) {
			System.err.println("error while trying to delete a waiting list entry");
			e.printStackTrace();
		}
		return false;
	}
	
	public static ArrayList<String> getCustomers() throws SQLException{
		ArrayList<String> data = new ArrayList<String>();
		Connection conn = DBConnection.getConnection();
		try {
			PreparedStatement p = conn.prepareStatement("select customer_id from customer");
			ResultSet r = p.executeQuery();
			while(r.next()) {
				data.add(r.getString("customer_id"));
			}
		}catch(Exception e) {
			System.err.println("error while trying to retrieve the list of customers");
			e.printStackTrace();
		}
		return data;
	}
	
	public static ArrayList<String> getCustomerReps() throws SQLException{
		ArrayList<String> data = new ArrayList<String>();
		Connection conn = DBConnection.getConnection();
		try {
			PreparedStatement p = conn.prepareStatement("select employee_id from customer_representatives");
			ResultSet r = p.executeQuery();
			while(r.next()) {
				data.add(r.getString("employee_id"));
			}
		}catch(Exception e) {
			System.err.println("error while trying to retrieve the list of customer reps");
			e.printStackTrace();
		}
		return data;
	}
	
	public static String customerMostRevenue() throws SQLException{
		Connection conn = DBConnection.getConnection();
		String customer = "";
		try {
			PreparedStatement p = conn.prepareStatement("select customer_id, max(total) as max_total from( " + 
					"select customer_id, sum(booking_fees) as total " + 
					"from buys " + 
					") as customer_totals");
			ResultSet r = p.executeQuery();
			if(r.next()) {
				customer = r.getString("customer_id");
			}
		}catch(Exception e) {
			System.err.println("error while trying to find the customer which generated the most revenue");
			e.printStackTrace();
		}
		return customer;
	}
	
	public static ArrayList<String> flightMostActive() throws SQLException{ 
		Connection conn = DBConnection.getConnection();
		ArrayList<String> data = new ArrayList<String>();
		try {
			PreparedStatement p = conn.prepareStatement("select t.flight_num from ( " + 
					"select v.flight_num, count(f.ticket_unique_num) as ticket_count " + 
					"from flight_tickets f inner join valid v " + 
					"on v.ticket_unique_num=f.ticket_unique_num " + 
					"where f.reserved='1' " + 
					"group by v.flight_num ) as t " + 
					"where t.ticket_count = (select max(t.ticket_count) from ( " + 
					"select v.flight_num, count(f.ticket_unique_num) as ticket_count " + 
					"from flight_tickets f inner join valid v " + 
					"on v.ticket_unique_num=f.ticket_unique_num " + 
					"where f.reserved='1' " + 
					"group by v.flight_num ) as b) ");
			ResultSet r = p.executeQuery();
			while(r.next()) {
				data.add(r.getString("flight_num"));
			}
		}catch(Exception e) {
			System.err.println("error while trying to get the most active flight");
			e.printStackTrace();
		}
		return data;
	}
	
	public static ArrayList<String> flightsAtAirport(String airport_id){
		ArrayList<String> data = new ArrayList<String>();
		Connection conn = DBConnection.getConnection();
		try {
			PreparedStatement p = conn.prepareStatement("select f.flight_num " + 
					"from flights f inner join arrive_at a on f.flight_num=a.flight_num " + 
					"where a.airport_id=? " + 
					"union " + 
					"select f.flight_num\n" + 
					"from flights f inner join depart_from d on f.flight_num=d.flight_num " + 
					"where d.airport_id=?");
			p.setString(1,airport_id);
			p.setString(2,airport_id);
			ResultSet r = p.executeQuery();
			while(r.next()) {
				data.add(r.getString("flight_num"));
			}
		}catch(Exception e) {
			System.err.println("error while trying to get the flights at an airport");
			e.printStackTrace();
		}
		return data;
	}
	
	public static List<CustomerData> reservationsByFlight(String flight_num) throws SQLException {
		List<CustomerData> data = new ArrayList<CustomerData>();
		try {
    		Connection conn = DBConnection.getConnection();
    		String flightsQuery="select m.ticket_unique_num, t.class, t.meal, t.seat_number, f.flight_num,  d.airport_id as departing , d.departure_time,a.airport_id as arrival, a.arrival_time, v.airline_id as airline, u.aircraft_registration as aircraft,b.booking_fees,t.fare from airport.make_book_have__list_Reservation m inner join flight_tickets t on m.ticket_unique_num=t.ticket_unique_num inner join buys b on t.ticket_unique_num=b.ticket_unique_num inner join flights f on t.senquence=f.flight_num inner join depart_from d on f.flight_num=d.flight_num inner join arrive_at a on f.flight_num=a.flight_num inner join via v on f.flight_num=v.flight_num inner join uses u on f.flight_num=u.flight_num where f.flight_num=?";
    		PreparedStatement p = conn.prepareStatement(flightsQuery);
    		p.setString(1, flight_num);
    		ResultSet r = p.executeQuery();
    		while(r.next()) {
    			CustomerData d = new CustomerData();
    			d.setTicket_unique_num(r.getString("ticket_unique_num"));
    			d.setFlight_num(r.getString("flight_num"));
    			d.setSeat_number(r.getString("seat_number"));
    			d.setMeal(r.getString("meal"));
    			d.setDeparting(r.getString("departing"));
    			d.setDeparture_time(r.getString("departure_time"));
    			d.setArrival(r.getString("arrival"));
    			d.setArrival_time(r.getString("arrival_time"));
    			d.setAirline(r.getString("airline"));
    			d.setAircraft(r.getString("aircraft"));
    			d.setBooking_fees(r.getString("booking_fees"));
    			d.setFare(r.getString("fare"));
    			data.add(d);
    		}
    	} catch(Exception e) {
    		System.err.println("error while tyring to get the list of reservations by flight number");
    		e.printStackTrace();
    	}
		return data;
	}
	
	public static List<CustomerData> reservationsByAirline(String airline_id) throws SQLException {
		List<CustomerData> data = new ArrayList<CustomerData>();
		try {
    		Connection conn = DBConnection.getConnection();
    		String flightsQuery="select m.ticket_unique_num, t.class, t.meal, t.seat_number, f.flight_num,  d.airport_id as departing , d.departure_time,a.airport_id as arrival, a.arrival_time, v.airline_id as airline, u.aircraft_registration as aircraft,b.booking_fees,t.fare from airport.make_book_have__list_Reservation m inner join flight_tickets t on m.ticket_unique_num=t.ticket_unique_num inner join buys b on t.ticket_unique_num=b.ticket_unique_num inner join flights f on t.senquence=f.flight_num inner join depart_from d on f.flight_num=d.flight_num inner join arrive_at a on f.flight_num=a.flight_num inner join via v on f.flight_num=v.flight_num inner join uses u on f.flight_num=u.flight_num where v.airline_id=?";
    		PreparedStatement p = conn.prepareStatement(flightsQuery);
    		p.setString(1, airline_id);
    		ResultSet r = p.executeQuery();
    		while(r.next()) {
    			CustomerData d = new CustomerData();
    			d.setTicket_unique_num(r.getString("ticket_unique_num"));
    			d.setFlight_num(r.getString("flight_num"));
    			d.setSeat_number(r.getString("seat_number"));
    			d.setMeal(r.getString("meal"));
    			d.setDeparting(r.getString("departing"));
    			d.setDeparture_time(r.getString("departure_time"));
    			d.setArrival(r.getString("arrival"));
    			d.setArrival_time(r.getString("arrival_time"));
    			d.setAirline(r.getString("airline"));
    			d.setAircraft(r.getString("aircraft"));
    			d.setBooking_fees(r.getString("booking_fees"));
    			d.setFare(r.getString("fare"));
    			data.add(d);
    		}
    	} catch(Exception e) {
    		System.err.println("error while tyring to get the list of reservations by airline");
    		e.printStackTrace();
    	}
		return data;
	}
	
	public static ArrayList<String> getReservedMonths() throws SQLException{
		ArrayList<String> data = new ArrayList<String>();
		Connection conn = DBConnection.getConnection();
		try {
			PreparedStatement p = conn.prepareStatement("select distinct month from( " + 
					"select distinct substring(arrival_time,1,7) as month from( " + 
					"select distinct arrival_time from make_book_have__list_Reservation i inner join arrive_at a on i.flight_num=a.flight_num) as arr " + 
					"union " + 
					"select distinct substring(departure_time,1,7) as month from( " + 
					"select distinct departure_time from make_book_have__list_Reservation i inner join depart_from d on i.flight_num-d.flight_num) as dpt) as months");
			ResultSet r = p.executeQuery();
			while(r.next()) {
				data.add(r.getString("month"));
			}
		}catch(Exception e) {
			System.err.println("error when trying to get the lisrt of months");
			e.printStackTrace();
		}
		return data;
	}
	
	public static List<CustomerData> reservationsByMonth(String month) throws SQLException {
		List<CustomerData> data = new ArrayList<CustomerData>();
		try {
    		Connection conn = DBConnection.getConnection();
    		String flightsQuery="select m.ticket_unique_num, t.class, t.meal, t.seat_number, f.flight_num,  d.airport_id as departing , d.departure_time,a.airport_id as arrival, a.arrival_time, v.airline_id as airline, u.aircraft_registration as aircraft,b.booking_fees,t.fare " + 
    				"from airport.make_book_have__list_Reservation m " + 
    				"inner join flight_tickets t on m.ticket_unique_num=t.ticket_unique_num " + 
    				"inner join buys b on t.ticket_unique_num=b.ticket_unique_num " + 
    				"inner join flights f on t.senquence=f.flight_num " + 
    				"inner join depart_from d on f.flight_num=d.flight_num " + 
    				"inner join arrive_at a on f.flight_num=a.flight_num " + 
    				"inner join via v on f.flight_num=v.flight_num " + 
    				"inner join uses u on f.flight_num=u.flight_num " + 
    				"where substring(d.departure_time,1,7)=? or substring(a.arrival_time,1,7)=?";
    		PreparedStatement p = conn.prepareStatement(flightsQuery);
    		p.setString(1, month);
    		p.setString(2,month);
    		ResultSet r = p.executeQuery();
    		while(r.next()) {
    			CustomerData d = new CustomerData();
    			d.setTicket_unique_num(r.getString("ticket_unique_num"));
    			d.setFlight_num(r.getString("flight_num"));
    			d.setSeat_number(r.getString("seat_number"));
    			d.setMeal(r.getString("meal"));
    			d.setDeparting(r.getString("departing"));
    			d.setDeparture_time(r.getString("departure_time"));
    			d.setArrival(r.getString("arrival"));
    			d.setArrival_time(r.getString("arrival_time"));
    			d.setAirline(r.getString("airline"));
    			d.setAircraft(r.getString("aircraft"));
    			d.setBooking_fees(r.getString("booking_fees"));
    			d.setFare(r.getString("fare"));
    			data.add(d);
    		}
    	} catch(Exception e) {
    		System.err.println("error while tyring to get the list of reservations by airline");
    		e.printStackTrace();
    	}
		return data;
	}
	
	public static ArrayList<AircraftData> getAircraft() throws SQLException{
		ArrayList<AircraftData> data = new ArrayList<AircraftData>();
		Connection conn = DBConnection.getConnection();
		try {
			PreparedStatement p = conn.prepareStatement("select * from aircrafts");
			ResultSet r = p.executeQuery();
			while(r.next()) {
				AircraftData d = new AircraftData();
				d.setAircraft_id(r.getString("aircraft_registration"));
				d.setCapacity(r.getString("num_seats"));
				d.setType(r.getString("type"));
				d.setName(r.getString("name"));
				data.add(d);
			}
		}catch(Exception e) {
			System.err.println("error when trying to get aircraft");
			e.printStackTrace();
		}
		return data;
	}
	
	public static boolean editAircraft(String aircraft_id, String name, String type, String capacity) throws SQLException{
		Connection conn = DBConnection.getConnection();
		try {
			PreparedStatement p = conn.prepareStatement("UPDATE aircrafts SET num_seats =? ,type =?, name=? where aircraft_registration=?");
			p.setString(1,capacity);
			p.setString(2,type);
			p.setString(3,name);
			p.setString(4,aircraft_id);
			p.executeUpdate();
			return true;
		}catch(Exception e) {
			System.err.println("error when trying to edit aircraft");
			e.printStackTrace();
		}
		return false;
	}
	
	public static boolean addAircraft(String aircraft_id, String name, String type, String capacity) throws SQLException{
		Connection conn = DBConnection.getConnection();
		try {
			PreparedStatement p = conn.prepareStatement("insert into aircrafts values (?,?,?,?)");
			p.setString(1,aircraft_id);
			p.setString(2,capacity);
			p.setString(3,type);
			p.setString(4,name);
			p.execute();
			return true;
		}catch(Exception e) {
			System.err.println("error when trying to add aircraft");
			e.printStackTrace();
		}
		return false;
	}
	
	public static boolean deleteAircraft(String aircraft_id) throws SQLException{
		Connection conn = DBConnection.getConnection();
		try {
			PreparedStatement p = conn.prepareStatement("delete from aircrafts where aircraft_registration =?");
			p.setString(1,aircraft_id);
			p.executeUpdate();
			return true;
		}catch(Exception e) {
			System.err.println("error when trying to delete aircraft");
			e.printStackTrace();
		}
		return false;
	}
}
