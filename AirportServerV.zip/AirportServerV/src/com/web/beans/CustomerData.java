package com.web.beans;

import java.io.Serializable;

public class CustomerData implements Serializable{

	private static final long serialVersionUID = 1L;
	/*
	 * 					<td> <%=r.getString("ticket_unique_num") %> </td>
                    	<td> <%=r.getString("flight_num") %></td>
                    	<td> <%=r.getString("seat_number") %></td>
                    	<td> <%=r.getString("meal") %></td>
                    	<td> <%=r.getString("departing") %></td>
                    	<td> <%=r.getString("departure_time") %></td>
                    	<td> <%=r.getString("arrival") %></td>
                    	<td> <%=r.getString("arrival_time") %></td>
                    	<td> <%=r.getString("airline") %></td>
                    	<td> <%=r.getString("aircraft") %></td>
	 */
	private String ticket_unique_num;
	private String flight_num;
	private String seat_number;
	private String meal;
	private String departing;
	private String departure_time;
	private String arrival;
	private String arrival_time;
	private String airline;
	private String aircraft;
	private String booking_fees;
	private String fare;
	public String getTicket_unique_num() {
		return ticket_unique_num;
	}
	public void setTicket_unique_num(String ticket_unique_num) {
		this.ticket_unique_num = ticket_unique_num;
	}
	public String getFlight_num() {
		return flight_num;
	}
	public void setFlight_num(String flight_num) {
		this.flight_num = flight_num;
	}
	public String getSeat_number() {
		return seat_number;
	}
	public void setSeat_number(String seat_number) {
		this.seat_number = seat_number;
	}
	public String getMeal() {
		return meal;
	}
	public void setMeal(String meal) {
		this.meal = meal;
	}
	public String getDeparting() {
		return departing;
	}
	public void setDeparting(String departing) {
		this.departing = departing;
	}
	public String getDeparture_time() {
		return departure_time;
	}
	public void setDeparture_time(String departure_time) {
		this.departure_time = departure_time;
	}
	public String getArrival() {
		return arrival;
	}
	public void setArrival(String arrival) {
		this.arrival = arrival;
	}
	public String getArrival_time() {
		return arrival_time;
	}
	public void setArrival_time(String arrival_time) {
		this.arrival_time = arrival_time;
	}
	public String getAirline() {
		return airline;
	}
	public void setAirline(String airline) {
		this.airline = airline;
	}
	public String getAircraft() {
		return aircraft;
	}
	public void setAircraft(String aircraft) {
		this.aircraft = aircraft;
	}
	public String getBooking_fees() {
		return booking_fees;
	}
	public void setBooking_fees(String booking_fees) {
		this.booking_fees = booking_fees;
	}
	public String getFare() {
		return fare;
	}
	public void setFare(String fare) {
		this.fare = fare;
	}
}
