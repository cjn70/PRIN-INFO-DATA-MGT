package com.web.beans;

public class AircraftData {
	private String aircraft_id;
	private String capacity;
	private String type;
	private String name;
	public String getAircraft_id() {
		return aircraft_id;
	}
	public void setAircraft_id(String aircraft_id) {
		this.aircraft_id = aircraft_id;
	}
	public String getCapacity() {
		return capacity;
	}
	public void setCapacity(String capacity) {
		this.capacity = capacity;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
