package com.web.beans;

public class FlightData {
	private String departing;
	private String arriving;
	private String flight_num;
	private String departing_time;
	private String arriving_time;
	private String airline;
	public boolean isFull;
	public String getDeparting() {
		return departing;
	}
	public void setDeparting(String departing) {
		this.departing = departing;
	}
	public String getArriving() {
		return arriving;
	}
	public void setArriving(String arriving) {
		this.arriving = arriving;
	}
	public String getFlight_num() {
		return flight_num;
	}
	public void setFlight_num(String flight_num) {
		this.flight_num = flight_num;
	}
	public String getDeparting_time() {
		return departing_time;
	}
	public void setDeparting_time(String departing_time) {
		this.departing_time = departing_time;
	}
	public String getArriving_time() {
		return arriving_time;
	}
	public void setArriving_time(String arriving_time) {
		this.arriving_time = arriving_time;
	}
	public String getAirline() {
		return airline;
	}
	public void setAirline(String airline) {
		this.airline = airline;
	}
}
