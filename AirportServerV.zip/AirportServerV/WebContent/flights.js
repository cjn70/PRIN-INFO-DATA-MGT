/**
 * 
 */
/**
 * methods for the tickets.jsp file
 */
function sort(){
	const sort_type = document.getElementById("sort").value;
	if(sort_type=="Take-Off"){
		takeOff();
	}
	else if(sort_type=="Landing-Time"){
		landingTime();
	}else{}
}


function takeOff(){
	//TAKEN FROM W3SCHOOLS SORT TUTOIRIAL
	var table, rows, switching, i, x, y, shouldSwitch;
	  table = document.getElementById("table");
	  switching = true;
	  /* Make a loop that will continue until
	  no switching has been done: */
	  while (switching) {
	    // Start by saying: no switching is done:
	    switching = false;
	    rows = table.rows;
	    /* Loop through all table rows (except the
	    first, which contains table headers): */
	    for (i = 1; i < (rows.length - 1); i++) {
	      // Start by saying there should be no switching:
	      shouldSwitch = false;
	      /* Get the two elements you want to compare,
	      one from current row and one from the next: */
	      x = rows[i].getElementsByTagName("TD")[2];
	      y = rows[i + 1].getElementsByTagName("TD")[2];
	      
	      var xYear,xMonth,xDay,xHour,xMin,xDate;
	      var yYear,yMonth,yDay,yHour,yMin,yDate;
	      xYear = x.innerHTML.substring(0,4);
	      xMonth = x.innerHTML.substring(5,7);
	      xDay = x.innerHTML.substring(8,10);
	      xHour = x.innerHTML.substring(11,13);
	      xMin = x.innerHTML.substring(14,16);
	      yYear = y.innerHTML.substring(0,4);
	      yMonth = y.innerHTML.substring(5,7);
	      yDay = y.innerHTML.substring(8,10);
	      yHour = y.innerHTML.substring(11,13);
	      yMin = y.innerHTML.substring(14,16);
	      
	      xDate = new Date(xYear,xMonth,xDay,xHour,xMin,0,0);
	      yDate = new Date(yYear,yMonth,yDay,yHour,yMin,0,0);
	      //console.log(yDate.toDateString());
	      //console.log(xDate.toDateString);
	      
	      // Check if the two rows should switch place:
	      if (xDate.valueOf() > yDate.valueOf()) {
	        // If so, mark as a switch and break the loop:
	        shouldSwitch = true;
	        break;
	      }
	    }
	    if (shouldSwitch) {
	      /* If a switch has been marked, make the switch
	      and mark that a switch has been done: */
	      rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
	      switching = true;
	    }
	  }
}

function landingTime(){
	//TAKEN FROM W3SCHOOLS SORT TUTOIRIAL
	var table, rows, switching, i, x, y, shouldSwitch;
	  table = document.getElementById("table");
	  switching = true;
	  /* Make a loop that will continue until
	  no switching has been done: */
	  while (switching) {
	    // Start by saying: no switching is done:
	    switching = false;
	    rows = table.rows;
	    /* Loop through all table rows (except the
	    first, which contains table headers): */
	    for (i = 1; i < (rows.length - 1); i++) {
	      // Start by saying there should be no switching:
	      shouldSwitch = false;
	      /* Get the two elements you want to compare,
	      one from current row and one from the next: */
	      x = rows[i].getElementsByTagName("TD")[4];
	      y = rows[i + 1].getElementsByTagName("TD")[4];
	      
	      var xYear,xMonth,xDay,xHour,xMin,xDate;
	      var yYear,yMonth,yDay,yHour,yMin,yDate;
	      xYear = x.innerHTML.substring(0,4);
	      console.log("year: " + xYear);
	      xMonth = x.innerHTML.substring(5,7);
	      console.log(xMonth);
	      xDay = x.innerHTML.substring(8,10);
	      console.log(xDay);
	      xHour = x.innerHTML.substring(11,13);
	      console.log(xHour);
	      xMin = x.innerHTML.substring(14,16);
	      console.log(xMin);
	      console.log(xYear);
	      yYear = y.innerHTML.substring(0,4);
	      yMonth = y.innerHTML.substring(5,7);
	      yDay = y.innerHTML.substring(8,10);
	      yHour = y.innerHTML.substring(11,13);
	      yMin = y.innerHTML.substring(14,16);
	      
	      xDate = new Date(xYear,xMonth,xDay,xHour,xMin,0,0);
	      yDate = new Date(yYear,yMonth,yDay,yHour,yMin,0,0);
	      
	      // Check if the two rows should switch place:
	      if (xDate.valueOf() < yDate.valueOf()) {
	        // If so, mark as a switch and break the loop:
	        shouldSwitch = true;
	        break;
	      }
	    }
	    if (shouldSwitch) {
	      /* If a switch has been marked, make the switch
	      and mark that a switch has been done: */
	      rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
	      switching = true;
	    }
	  }
}

function filterStops(){
	
}

function filterAirline(){
	//PARTIALLY TAKEN FROM W3SCHOOLS FILTER TABLE TUTORIAL
	 var input, x, table, rows;
	  input = document.getElementById("airline-filter");
	  table = document.getElementById("table");
	  rows = table.rows;
	  for (i = 1; i < (rows.length); i++) {
	      /* Get the two elements you want to compare,
	      one from current row and one from the next: */
	      x = rows[i].getElementsByTagName("TD")[5];
	      // Check if the row should not be filtered:
	      if(input.value!=""){
		      if (x.innerHTML.toUpperCase().indexOf(input.value.toUpperCase()) > -1) {
		        // If so, make the display style default
		    	  rows[i].style.display = "";
		      } else {
		        rows[i].style.display = "none";
		      }
	      }
	      else{
	    	  rows[i].style.display = "";
	      }
	    }
}





